package com.jarvis.assistant

import android.app.Application
import com.jarvis.assistant.crash.CrashHandler

class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler(CrashHandler(this))
    }
}
