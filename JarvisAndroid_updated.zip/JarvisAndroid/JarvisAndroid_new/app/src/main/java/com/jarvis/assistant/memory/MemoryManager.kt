package com.jarvis.assistant.memory

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Very small persistent memory store, equivalent to memory/memory.example.json
 * in the desktop version. Stored as a flat JSON object of key -> value strings
 * in the app's private files directory.
 */
class MemoryManager(private val context: Context) {

    private val file: File
        get() = File(context.filesDir, "memory.json")

    private fun readAll(): JSONObject {
        if (!file.exists()) return JSONObject()
        return try {
            JSONObject(file.readText())
        } catch (e: Exception) {
            JSONObject()
        }
    }

    private fun writeAll(obj: JSONObject) {
        file.writeText(obj.toString(2))
    }

    fun save(key: String, value: String) {
        val obj = readAll()
        obj.put(key, value)
        writeAll(obj)
    }

    fun delete(key: String): Boolean {
        val obj = readAll()
        if (!obj.has(key)) return false
        obj.remove(key)
        writeAll(obj)
        return true
    }

    fun getAll(): Map<String, String> {
        val obj = readAll()
        val map = mutableMapOf<String, String>()
        for (k in obj.keys()) map[k] = obj.getString(k)
        return map
    }

    fun asContextString(): String {
        val all = getAll()
        if (all.isEmpty()) return ""
        return all.entries.joinToString("\n") { "- ${it.key}: ${it.value}" }
    }
}
