package com.jarvis.assistant.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * A glowing particle orb that visually reflects what JARVIS is doing:
 * blue = listening, yellow = thinking, green = speaking, red = error.
 */
class OrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class State(val color: Int) {
        LISTENING(Color.parseColor("#00D1FF")),
        THINKING(Color.parseColor("#FFD54A")),
        SPEAKING(Color.parseColor("#4CE07A")),
        ERROR(Color.parseColor("#FF5252")),
        IDLE(Color.parseColor("#3A4A55"))
    }

    private var currentState: State = State.IDLE
    private var displayColor: Int = currentState.color

    private data class Particle(var angle: Float, var radius: Float, var speed: Float, var size: Float)
    private val particles = List(18) {
        Particle(
            angle = Random.nextFloat() * 360f,
            radius = 0.4f + Random.nextFloat() * 0.55f,
            speed = 0.4f + Random.nextFloat() * 1.2f,
            size = 3f + Random.nextFloat() * 4f
        )
    }

    private var pulsePhase = 0f
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulsePhase = it.animatedValue as Float
            for (p in particles) {
                p.angle = (p.angle + p.speed) % 360f
            }
            invalidate()
        }
    }

    init {
        animator.start()
    }

    fun setState(state: State) {
        if (currentState == state) return
        currentState = state
        displayColor = state.color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (minOf(width, height) / 2f) * 0.32f
        val pulse = 1f + 0.08f * sin(Math.toRadians(pulsePhase * 3.0)).toFloat()
        val coreRadius = baseRadius * pulse

        // Soft glow behind the core.
        corePaint.shader = RadialGradient(
            cx, cy, coreRadius * 2.6f,
            intArrayOf(colorWithAlpha(displayColor, 90), colorWithAlpha(displayColor, 0)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, coreRadius * 2.6f, corePaint)

        // Solid core.
        corePaint.shader = null
        corePaint.color = displayColor
        canvas.drawCircle(cx, cy, coreRadius, corePaint)

        // Orbiting particles.
        particlePaint.color = displayColor
        for (p in particles) {
            val rad = Math.toRadians(p.angle.toDouble())
            val orbitRadius = baseRadius * p.radius * 2.1f
            val px = cx + (orbitRadius * cos(rad)).toFloat()
            val py = cy + (orbitRadius * sin(rad)).toFloat()
            particlePaint.alpha = 200
            canvas.drawCircle(px, py, p.size, particlePaint)
        }
    }

    private fun colorWithAlpha(color: Int, alpha: Int): Int {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }
}
