package com.jarvis.assistant.actions

import android.content.Context
import android.content.Intent
import android.net.Uri

object MediaActions {

    fun playYoutube(context: Context, query: String): String {
        // vnd.youtube search intent opens directly in the YouTube app if installed,
        // and falls back to the browser search results otherwise.
        val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:${Uri.encode(query)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(ytIntent)
            "YouTube'da \"$query\" açılıyor."
        } catch (e: Exception) {
            BrowserActions.openUrl(context, "https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        }
    }

    fun playSpotify(context: Context, query: String): String {
        val spotifyUri = Uri.parse("spotify:search:${Uri.encode(query)}")
        val intent = Intent(Intent.ACTION_VIEW, spotifyUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            "Spotify'da \"$query\" aranıyor."
        } catch (e: Exception) {
            BrowserActions.openUrl(context, "https://open.spotify.com/search/${Uri.encode(query)}")
        }
    }

    fun play(context: Context, query: String, provider: String): String {
        return when (provider.lowercase()) {
            "spotify" -> playSpotify(context, query)
            else -> playYoutube(context, query)
        }
    }
}
